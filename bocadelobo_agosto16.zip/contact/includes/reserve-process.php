<?php
/*
Credits: Bit Repository
URL: http://www.bitrepository.com/
*/

include dirname(dirname(__FILE__)).'/config.php';

error_reporting (E_ALL ^ E_NOTICE);

$post = (!empty($_POST)) ? true : false;

if($post)
{
include 'functions.php';

$name = stripslashes($_POST['fullname']);
$email = trim($_POST['email']);
$message = stripslashes($_POST['message']);
$date = stripslashes($_POST['date']);
$people = stripslashes($_POST['people']);
$telephone = stripslashes($_POST['telephone']);

$error = '';

// Check name

if(!$name)
{
$error .= 'Por favor ingresa tu nombre.<br />';
}

// Check email

if(!$email)
{
$error .= 'Please enter an e-mail address.<br />';
}

if($email && !ValidateEmail($email))
{
$error .= 'Please enter a valid e-mail address.<br />';
}

// Check message (length)

if(!$message || strlen($message) < 15)
{
$error .= "Please enter your message. It should have at least 15 characters.<br />";
}

if(!$error)
{
	$mail = @mail(WEBMASTER_EMAIL, "You have a new message.", 
					$name . ' booked on ' . $date . ' with ' . $people . ' people. Contact number: ' . 
					$telephone . '.' . $message,
					"From: ".$name." <".$email.">\r\n"
					."Reply-To: ".$email."\r\n"
					."X-Mailer: PHP/" . phpversion());


	if($mail)
	{
	echo 'OK';
	}
	
	}
	else
	{
	echo '<div class="notification_error">'.$error.'</div>';
	}

}
?>