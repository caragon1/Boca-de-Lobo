<?php
/*
Credits: Bit Repository
URL: http://www.bitrepository.com/
*/

include dirname(dirname(__FILE__)).'/config.php';

error_reporting (E_ALL ^ E_NOTICE);

$post = (!empty($_POST)) ? true : false;

if($post)
{
include 'functions.php';

$name = stripslashes($_POST['name']);
$email = trim($_POST['email']);
$message = stripslashes($_POST['message']);

$error = '';

// Check name

if(!$name)
{
$error .= 'Por favor ingresa tu nombre.<br />';
}

// Check email

if(!$email)
{
$error .= 'Por favor ingresa una direccion de correo.<br />';
}

if($email && !ValidateEmail($email))
{
$error .= 'Por favor ingresa una direccion de correo valida.<br />';
}

// Check message (length)

if(!$message || strlen($message) < 15)
{
$error .= "Por favor ingresa tu mensaje (15 caracteres minimo).<br />";
}

if(!$error)
{
	$mail = @mail(WEBMASTER_EMAIL, "Tienes un nuevo mensaje.", $message,
		 "From: ".$name." <info@bocadelobo.com>\r\n"
		."Reply-To: ".$email."\r\n"
		."X-Mailer: PHP/" . phpversion(),'-f info@bocadelobosv.com');


	if($mail)
	{
	echo 'OK';
	}
	
	}
	else
	{
	echo '<div class="notification_error">'.$error.'</div>';
	}

}
?>