<?php
// Where will you get the forms' results?
define("WEBMASTER_EMAIL", 'yourname@yourdomain.com');
?>